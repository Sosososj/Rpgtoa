<?php

/* Setting the error log to a file called xd.log. */
ini_set("log_errors", TRUE);
ini_set('error_log', "./errors.log");


//////////////// Sumar Dias formato php
function segundosAntispam($timestamp,$minutes){
    $future = $timestamp + (1*str_replace('s','',$minutes));
    return $future;
}


function noAutorizado($userId){
    global $chat_id;
    global $msg_id;
        $conn = mysqli_connect('mysql-perromlp.alwaysdata.net','perromlp','Regalo1324@Xs','perromlp_pro');
       $sql = "SELECT * FROM administrar WHERE id='$userId'";
    $cs = mysqli_query($conn,$sql);
    $raw = mysqli_fetch_assoc($cs);
    $rango = $raw['plan'];

    if($rango == "Free User"){
  $content = ['chat_id' => $chat_id, 'text' => "Acceso denegado a Mikaza, Usted necesita comprar Premium, hable con los administradores para mas informacion", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
            SendMessage($content);
exit;
        return true;
    }else{
        return false;
    }

}



function enviarPM($userId){