<?php

/* Setting the timezone. */
date_default_timezone_set("Asia/Kolkata");

/* Defining the bot token. */
define('bot_token','6064629163:AAHXIk1sYfg0mL7y28wXu-4O8WTXid5_6bg');
define('msgtext', $text);

$bot_username = "Naruto";

/* It's setting the date and time. */
$fecha = date('d-m-Y h:i:s A');

/* It's just a variable that contains the name of the owner of the bot. */
$propietario = "xXGEOREMIXx";

/* Getting the data from the POST request sent by Telegram. */
// $update =  json_decode(file_get_contents('php://input'), true);
$update = file_get_contents('php://input');
$update = json_decode($update,true);

$tlg = "<a href='tg://user?id=$user_id'>$ufname</a>";
$tlg2 = "<a href='tg://user?id=$callbackuserid'>".htmlspecialchars($callbackfname.$callbacklname)."</a>";

//basic
$text       = $update["message"]["text"];
// $text       = $update->message->text;
$photo      = $update["message"]["photo"];
$date       = $update["message"]["date"];
$chat_id    = $update["message"]["chat"]["id"];
$msg_id     = $update["message"]["message_id"];

//Chat
$cfname     = $update['message']['chat']['first_name'];
$cid        = $update["message"]["chat"]["id"];
$clast_name = $update['message']['chat']['last_name'];
$ctype      = $update["message"]["chat"]["type"];
$ctitle     = $update['message']['chat']['title'];