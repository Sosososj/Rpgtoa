<?php
require_once '/home/perromlp/www/project/data/data.php';
require_once '/home/perromlp/www/project/Resources/inline.php';


/* It's a variable that contains a string. */
$auth = "
ㄖ S͟e͟c͟c͟i͟o͟n͟ A͟u͟t͟h͟ ㄖ
 [ᘔ]𝖦𝖺𝗍𝖾𝗐𝖺𝗒 𝗌𝗉
      ༺[Stripe Auth]༻
     ಼➞𝖴𝗌𝖾:/sp ᴄᴄ|ᴍᴍ|ʏʏ|ᴄᴠᴠ
   ಼ ➥𝖲𝗍𝖺𝗍𝗎𝗌: [$zrstatus $zrtick]
     ಼ ➞𝖢𝗈𝗆𝗆𝖾𝗇𝗍: $zrcomment
────────────────────────
";


/* It's a variable that contains a string. */
$mass = "----------Gateways Mass [$]---------
────────────
[𖠧]Gateway le ($) 
[Stripe]
𝖴𝗌𝖾:/le ᴄᴄ|ᴍᴍ|ʏʏ|ᴄᴠᴠ
Status: [$massstatus $masstick]
Commentario: $masscomment";



/* It's a variable that contains a string. */
$charge = "
ㄖ S͟e͟c͟c͟i͟o͟n͟ C͟h͟a͟r͟g͟e͟d͟ ㄖ
  [ᘔ]𝖦𝖺𝗍𝖾𝗐𝖺𝗒 𝖯𝗉 ($) 
    ༺[Stripe]༻
     ಼➞𝖴𝗌𝖾: /pp ᴄᴄ|ᴍᴍ|ʏʏ|ᴄᴠᴠ
   ಼➥𝖲𝗍𝖺𝗍𝗎𝗌: [𝖮𝖥𝖥⚠️ $lestatus $letick]
     ಼➞𝖢𝗈𝗆𝗆𝖾𝗇𝗍: $lecomment
༺༶༶━━━━━━《 ༮ 》━━━━━━༶༶༻     
 [ᘔ]𝖦𝖺𝗍𝖾𝗐𝖺𝗒 𝖺𝗎(3$) 
  [Stripe]
     ಼➞𝖴𝗌𝖾: /au ᴄᴄ|ᴍᴍ|ʏʏ|ᴄᴠᴠ
   ಼➥𝖲𝗍𝖺𝗍𝗎𝗌: [𝖮𝖥𝖥⚠️ $lestatus $letick]
     ಼➞𝖢𝗈𝗆𝗆𝖾𝗇𝗍: $lecomment