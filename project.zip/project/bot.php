<?php

require_once 'requires.php';
require_once '/home/perromlp/www/project/data/data.php';


/* This is the code that is executed when the user sends the command `/start` or `.start` or `?start` or `#start` or `/start@` to the bot. */
if ($text == '/start' || $text == ".start" || $text == "?start" || $text == "#start" || $text == "/start@NarutoPrimeChkBot") {

    $keyboard = json_encode([
         "inline_keyboard" => [
            [
                ["text" => "⚜️𝙂𝘼𝙏𝙀𝙎⚜️", "callback_data" => "so"],
                ["text" => "🔰𝙋𝙀𝙍𝙁𝙄𝙇🔰", "callback_data" => "info"],
            ],
            [
                ["text" => "𝗖𝗲𝗿𝗿𝗮𝗿📛", "callback_data" => "exit"],
            ]
        ]
    ]);

$starttime = microtime(true);
    $SQL = "SELECT * FROM `administrar` WHERE id=".$user_id;
    $CONSULTA = mysqli_query(mysqlcon(),$SQL);
    $json_array = [];


    while ($row = mysqli_fetch_assoc($CONSULTA)) {
    $json_array[] = $row;
    }

    $final2 = json_encode($json_array);

    $plan =anicap($final2, '"plan":"','"');
    mysqli_close(mysqlcon());