-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2022 at 12:04 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tet`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrar`
--

CREATE TABLE `administrar` (
  `id` varchar(50) DEFAULT NULL,
  `rango` varchar(50) NOT NULL,
  `creditos` int(11) DEFAULT NULL,
  `antispam` int(11) DEFAULT NULL,
  `status` text NOT NULL,
  `warns` int(11) NOT NULL,
  `plan` text DEFAULT NULL,
  `planexpiry` text NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `administrar`